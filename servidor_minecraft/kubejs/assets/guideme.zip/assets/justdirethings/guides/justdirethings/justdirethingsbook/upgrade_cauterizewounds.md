---
navigation:
  title: "Cauterize Wounds"
  icon: "justdirethings:upgrade_cauterizewounds"
  position: 1
  parent: justdirethings:upgrades.md
item_ids:
  - justdirethings:upgrade_cauterizewounds
---

# Cauterize Wounds

Boost your survival chances with the Cauterize Wounds upgrade. This upgrade gives you the ability to heal rapidly after taking damage, using the heat of battle to seal wounds.

Activate this ability by right clicking - it will instantly heal you, and use some durability. Note there is a cooldown period before you can use it again.

## Cauterize Wounds Upgrade Crafting



<Recipe id="justdirethings:upgrade_cauterizewounds" />

