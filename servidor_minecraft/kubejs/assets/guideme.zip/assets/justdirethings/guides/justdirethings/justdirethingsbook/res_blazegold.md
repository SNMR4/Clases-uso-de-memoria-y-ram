---
navigation:
  title: "Blazegold Ingot"
  icon: "justdirethings:blazegold_ingot"
  position: 3
  parent: justdirethings:resources.md
item_ids:
  - justdirethings:blazegold_ingot
---

# Blazegold Ingot

Blazegold Ingots are derived from smelting Raw Blazegold, harvested from [Raw Blazegold Blocks](./res_blazegold_raw.md). These ingots are essential for crafting items imbued with magical properties.

## Smelting Raw Blazegold



<Recipe id="justdirethings:blazegold_ingot_smelted" />

