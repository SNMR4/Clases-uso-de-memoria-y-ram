---
navigation:
  title: "Celestigem Axe"
  icon: "justdirethings:celestigem_axe[justdirethings:forge_energy=10000]"
  position: 16
  parent: justdirethings:tools.md
item_ids:
  - justdirethings:celestigem_axe
---

# Celestigem Axe

Advancing from [Blazegold Axe](./tool_blazegold_axe.md), this axe harnesses Forge Energy, featuring a 10,000 FE storage. Maintain power levels with a [Pocket Generator](./item_pocket_generator.md).

Celestigem Axe Crafting

<Recipe id="justdirethings:celestigem_axe" />

