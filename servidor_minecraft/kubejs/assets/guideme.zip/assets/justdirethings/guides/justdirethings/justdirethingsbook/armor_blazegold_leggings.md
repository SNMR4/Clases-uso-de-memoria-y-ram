---
navigation:
  title: "Blazegold Leggings"
  icon: "justdirethings:blazegold_leggings"
  position: 7
  parent: justdirethings:armor.md
item_ids:
  - justdirethings:blazegold_leggings
---

# Blazegold Leggings

Blazegold Leggings offer superior mobility and protection. Utilize the Lava Repair ability by dropping these leggings into a lava source block for full repair.

## Blazegold Leggings Crafting



<Recipe id="justdirethings:blazegold_leggings" />

