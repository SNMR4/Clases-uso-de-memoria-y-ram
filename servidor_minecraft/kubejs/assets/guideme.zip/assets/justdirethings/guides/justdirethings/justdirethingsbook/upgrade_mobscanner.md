---
navigation:
  title: "Mob Scanner"
  icon: "justdirethings:upgrade_mobscanner"
  position: 1
  parent: justdirethings:upgrades.md
item_ids:
  - justdirethings:upgrade_mobscanner
---

# Mob Scanner

The Mob Scanner upgrade is an activated ability, and can be installed on swords starting at Ferricore. When you activate this ability, nearby enemies will appear with particles that you can see through blocks.

## Mob Scanner Upgrade Crafting



<Recipe id="justdirethings:upgrade_mobscanner" />

