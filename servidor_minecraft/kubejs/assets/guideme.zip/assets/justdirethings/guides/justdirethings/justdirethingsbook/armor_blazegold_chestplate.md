---
navigation:
  title: "Blazegold Chestplate"
  icon: "justdirethings:blazegold_chestplate"
  position: 6
  parent: justdirethings:armor.md
item_ids:
  - justdirethings:blazegold_chestplate
---

# Blazegold Chestplate

The Blazegold Chestplate not only provides enhanced defense but also features the Lava Repair ability. Drop this chestplate into a lava source block to fully repair it.

## Blazegold Chestplate Crafting



<Recipe id="justdirethings:blazegold_chestplate" />

