---
navigation:
  title: "Celestigem Chestplate"
  icon: "justdirethings:celestigem_chestplate[justdirethings:forge_energy=10000]"
  position: 10
  parent: justdirethings:armor.md
item_ids:
  - justdirethings:celestigem_chestplate
---

# Celestigem Chestplate

The Celestigem Chestplate uses Forge Energy for its functionality, equipped with a 10,000 FE capacity. It's ideal to use a [Pocket Generator](./item_pocket_generator.md) for keeping it continuously charged.

## Celestigem Chestplate Crafting



<Recipe id="justdirethings:celestigem_chestplate" />

