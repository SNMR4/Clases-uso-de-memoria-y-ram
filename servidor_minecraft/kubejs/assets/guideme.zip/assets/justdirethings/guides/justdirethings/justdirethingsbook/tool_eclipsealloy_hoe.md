---
navigation:
  title: "Eclipse Alloy Hoe"
  icon: "justdirethings:eclipsealloy_hoe[justdirethings:forge_energy=500000]"
  position: 24
  parent: justdirethings:tools.md
item_ids:
  - justdirethings:eclipsealloy_hoe
---

# Eclipse Alloy Hoe

The Eclipse Alloy Hoe is a revolution in agricultural technology, capable of turning earth into highly fertile soil. 

It supports the most advanced farming upgrades, maximizing crop yield and efficiency.

Eclipse Alloy Hoe Crafting

<Recipe id="justdirethings:eclipsealloy_hoe" />

