---
navigation:
  title: "Drop Teleport"
  icon: "justdirethings:upgrade_dropteleport"
  position: 1
  parent: justdirethings:upgrades.md
item_ids:
  - justdirethings:upgrade_dropteleport
---

# Drop Teleport

Ensure your loot is safe with the Drop Teleport upgrade. This innovative upgrade teleports dropped items directly into a bound inventory.

Shift right click the tool on an inventory, like a chest, to bind it. Now, any drops from ores or mobs will teleport directly there!

## Drop Teleport Upgrade Crafting



<Recipe id="justdirethings:upgrade_dropteleport" />

