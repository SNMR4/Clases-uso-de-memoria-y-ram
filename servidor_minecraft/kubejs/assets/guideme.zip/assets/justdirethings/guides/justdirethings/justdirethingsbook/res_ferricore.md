---
navigation:
  title: "Ferricore Ingot"
  icon: "justdirethings:ferricore_ingot"
  position: 1
  parent: justdirethings:resources.md
item_ids:
  - justdirethings:ferricore_ingot
---

# Ferricore Ingot

Ferricore Ingots are obtained by smelting Raw Ferricore, which is mined from [Raw Ferricore Blocks](./res_ferricore_raw.md). These ingots are enhanced for durability and strength, serving as a superior alternative to ordinary iron.

## Smelting Raw Ferricore



<Recipe id="justdirethings:ferricore_ingot_smelted" />

