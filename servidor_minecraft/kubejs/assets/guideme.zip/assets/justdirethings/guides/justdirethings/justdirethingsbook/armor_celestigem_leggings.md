---
navigation:
  title: "Celestigem Leggings"
  icon: "justdirethings:celestigem_leggings[justdirethings:forge_energy=10000]"
  position: 11
  parent: justdirethings:armor.md
item_ids:
  - justdirethings:celestigem_leggings
---

# Celestigem Leggings

Celestigem Leggings utilize Forge Energy, boasting a 10,000 FE capacity for enhanced durability. Charge them on the go with a [Pocket Generator](./item_pocket_generator.md).

## Celestigem Leggings Crafting



<Recipe id="justdirethings:celestigem_leggings" />

