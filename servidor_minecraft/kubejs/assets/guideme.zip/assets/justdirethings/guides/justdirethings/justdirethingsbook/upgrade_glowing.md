---
navigation:
  title: "Glowing"
  icon: "justdirethings:upgrade_glowing"
  position: 1
  parent: justdirethings:upgrades.md
item_ids:
  - justdirethings:upgrade_glowing
---

# Glowing

This upgrade will apply the 'glowing' effect to all nearby living entities - mobs and passive animals alike!

This is an activated ability, and replaces the Mob Scanner.

## Glowing Crafting



<Recipe id="justdirethings:upgrade_glowing" />

