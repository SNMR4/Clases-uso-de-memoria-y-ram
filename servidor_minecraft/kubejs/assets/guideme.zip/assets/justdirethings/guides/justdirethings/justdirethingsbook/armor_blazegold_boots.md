---
navigation:
  title: "Blazegold Boots"
  icon: "justdirethings:blazegold_boots"
  position: 8
  parent: justdirethings:armor.md
item_ids:
  - justdirethings:blazegold_boots
---

# Blazegold Boots

Blazegold Boots provide enhanced foot protection and come with the Lava Repair ability. To fully repair these boots, drop them into a lava source block.

## Blazegold Boots Crafting



<Recipe id="justdirethings:blazegold_boots" />

