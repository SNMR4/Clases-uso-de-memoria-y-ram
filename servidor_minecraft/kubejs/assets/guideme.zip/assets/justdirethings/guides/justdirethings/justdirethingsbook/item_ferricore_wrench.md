---
navigation:
  title: "Ferricore Wrench"
  icon: "justdirethings:ferricore_wrench"
  position: 3
  parent: justdirethings:items.md
item_ids:
  - justdirethings:ferricore_wrench
---

# Ferricore Wrench

The Ferricore Wrench is a versatile tool used to rotate blocks and link Swappers. A must-have for builders and technicians looking to optimize their constructions.

## Ferricore Wrench Crafting



<Recipe id="justdirethings:ferricore_wrench" />

