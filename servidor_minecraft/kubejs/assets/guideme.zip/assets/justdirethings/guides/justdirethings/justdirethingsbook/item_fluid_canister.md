---
navigation:
  title: "Fluid Canister"
  icon: "justdirethings:fluid_canister"
  position: 12
  parent: justdirethings:items.md
item_ids:
  - justdirethings:fluid_canister
---

# Fluid Canister

The Fluid Canister can hold up to 8 buckets of liquid. Right-click to place or pick up liquids, similar to a bucket.

Shift right-click to enable auto-filling of other fluid containers in your inventory. There are three settings: 'None', Just Dire Things items only, and 'ALL' (fills all fluid holders, including from other mods).

## Fluid Canister Crafting



<Recipe id="justdirethings:fluid_canister" />

