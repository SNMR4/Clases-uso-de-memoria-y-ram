---
navigation:
  title: "Homing"
  icon: "justdirethings:upgrade_homing"
  position: 1
  parent: justdirethings:upgrades.md
item_ids:
  - justdirethings:upgrade_homing
---

# Homing

Enhance your precision with the Homing upgrade. Projectiles modified with this upgrade will seek out nearby targets, ensuring your shots never miss.

## Homing Crafting



<Recipe id="justdirethings:upgrade_homing" />

