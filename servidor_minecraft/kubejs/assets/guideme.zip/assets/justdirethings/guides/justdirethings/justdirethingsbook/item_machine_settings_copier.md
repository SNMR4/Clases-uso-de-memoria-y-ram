---
navigation:
  title: "Machine Settings Copier"
  icon: "justdirethings:machinesettingscopier"
  position: 9
  parent: justdirethings:items.md
item_ids:
  - justdirethings:machinesettingscopier
---

# Machine Settings Copier

This tool allows for the copying of machine settings. Shift-right click on a [Machine](./machines.md) to copy its settings, then right click on another machine to paste them. Click in the air to open a menu and select specific settings to copy.

## Machine Settings Copier Crafting



<Recipe id="justdirethings:machinesettingscopier" />

