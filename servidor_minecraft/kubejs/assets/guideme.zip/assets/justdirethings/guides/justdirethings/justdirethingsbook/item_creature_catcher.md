---
navigation:
  title: "Creature Catcher"
  icon: "justdirethings:creaturecatcher"
  position: 8
  parent: justdirethings:items.md
item_ids:
  - justdirethings:creaturecatcher
---

# Creature Catcher

The Creature Catcher is an innovative tool for capturing and releasing entities. Simply throw it at an entity to capture it, and toss it again to release the captured entity.

You can also use it in some filters to filter very specific types of entities, such as only filtering blue sheep.

## Creature Catcher Crafting



<Recipe id="justdirethings:creaturecatcher" />

