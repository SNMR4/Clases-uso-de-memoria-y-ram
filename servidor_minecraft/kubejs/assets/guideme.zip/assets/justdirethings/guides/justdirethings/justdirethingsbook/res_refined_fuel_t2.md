---
navigation:
  title: "Refined Blaze Ember Fuel"
  icon: "justdirethings:refined_t2_fluid_bucket"
  position: 27
  parent: justdirethings:resources.md
---

# Refined Blaze Ember Fuel

Refined Blaze Ember Fuel is a potent source of energy. It is produced by processing Unrefined Blaze Ember Fuel, which is obtained by dropping [Blaze Ember](./res_coal_t2.md) into [Polymorphic Fluid](./res_polymorphic_fluid.md). Place this mixture beside a Blazebloom Goo block to refine it.

Refined Blaze Ember Fuel is an efficient fuel, and can be used to generate energy in the [Fuel Generator](./mach_generatorfluidt1.md).

