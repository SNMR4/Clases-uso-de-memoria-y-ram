---
navigation:
  title: "Eclipse Alloy Boots"
  icon: "justdirethings:eclipsealloy_boots[justdirethings:forge_energy=500000]"
  position: 23
  parent: justdirethings:armor.md
item_ids:
  - justdirethings:eclipsealloy_boots
---

# Eclipse Alloy Boots

These advanced boots store up to 500,000 FE, providing excellent mobility and energy absorption. Always keep them charged via a [Pocket Generator](./item_pocket_generator.md) for best results.

## Eclipse Alloy Boots Crafting



<Recipe id="justdirethings:eclipsealloy_boots" />

