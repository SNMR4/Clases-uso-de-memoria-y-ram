---
navigation:
  title: "Night Vision"
  icon: "justdirethings:upgrade_nightvision"
  position: 1
  parent: justdirethings:upgrades.md
item_ids:
  - justdirethings:upgrade_nightvision
---

# Night Vision

Navigate the dark with ease using the Night Vision upgrade. This upgrade grants permanent night vision, illuminating your surroundings at all times.

## Night Vision Crafting



<Recipe id="justdirethings:upgrade_nightvision" />

