---
navigation:
  title: "Blazegold Sword"
  icon: "justdirethings:blazegold_sword"
  position: 7
  parent: justdirethings:tools.md
item_ids:
  - justdirethings:blazegold_sword
---

# Blazegold Sword

Enhanced damage over the [Ferricore Sword](./tool_ferricore_sword.md). Features 'Lava Repair' for full repair when dropped into lava.

Blazegold Sword Crafting

<Recipe id="justdirethings:blazegold_sword" />

