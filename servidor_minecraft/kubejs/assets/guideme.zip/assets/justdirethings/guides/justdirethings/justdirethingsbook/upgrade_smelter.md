---
navigation:
  title: "Smelter"
  icon: "justdirethings:upgrade_smelter"
  position: 1
  parent: justdirethings:upgrades.md
item_ids:
  - justdirethings:upgrade_smelter
---

# Smelter

Instantly smelt items with the Smelter upgrade. Applied to tools, this upgrade allows you to directly obtain smelted products from mined ores.

Uses some durability.

## Smelter Upgrade Crafting



<Recipe id="justdirethings:upgrade_smelter" />

