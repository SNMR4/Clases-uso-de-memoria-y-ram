---
navigation:
  title: "Advanced Clicker"
  icon: "justdirethings:clickert2"
  position: 8
  parent: justdirethings:machines.md
item_ids:
  - justdirethings:clickert2
---

# Advanced Clicker

The Advanced Clicker is an upgraded version of the [Simple Clicker](./mach_clickert1.md).It can affect a larger area, and will also support filtering blocks or entities.

Use a spawn egg or creature catcher to filter entities.

This can be used for a mob farm, if set to left click hostiles, or an animal breeder if set to right click adults!

## Advanced Clicker



<Recipe id="justdirethings:clickert2" />

