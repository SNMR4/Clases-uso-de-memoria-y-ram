---
navigation:
  title: "Celestigem Helmet"
  icon: "justdirethings:celestigem_helmet[justdirethings:forge_energy=10000]"
  position: 9
  parent: justdirethings:armor.md
item_ids:
  - justdirethings:celestigem_helmet
---

# Celestigem Helmet

The Celestigem Helmet harnesses Forge Energy for durability, storing up to 10,000 FE. Keep it charged using a [Pocket Generator](./item_pocket_generator.md).

## Celestigem Helmet Crafting



<Recipe id="justdirethings:celestigem_helmet" />

