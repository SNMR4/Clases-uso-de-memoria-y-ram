---
navigation:
  title: "Celestigem Sword"
  icon: "justdirethings:celestigem_sword[justdirethings:forge_energy=10000]"
  position: 13
  parent: justdirethings:tools.md
item_ids:
  - justdirethings:celestigem_sword
---

# Celestigem Sword

An upgrade to [Blazegold Sword](./tool_blazegold_sword.md), this sword uses Forge Energy instead of durability. It holds 10,000 FE, best kept charged with a [Pocket Generator](./item_pocket_generator.md).

Celestigem Sword Crafting

<Recipe id="justdirethings:celestigem_sword" />

