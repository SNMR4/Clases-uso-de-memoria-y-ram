---
navigation:
  title: "Upgrades"
  icon: "justdirethings:upgrade_mobscanner"
  position: 5
---

# Upgrades

<SubPages />