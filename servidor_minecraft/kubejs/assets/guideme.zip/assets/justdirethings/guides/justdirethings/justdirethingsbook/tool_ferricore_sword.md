---
navigation:
  title: "Ferricore Sword"
  icon: "justdirethings:ferricore_sword"
  position: 1
  parent: justdirethings:tools.md
item_ids:
  - justdirethings:ferricore_sword
---

# Ferricore Sword

The Ferricore Sword is a robust melee weapon slightly superior to traditional iron swords. Crafted from Ferricore, it not only provides enhanced damage but also offers the potential for further upgrades with special abilities, enhancing its utility in combat scenarios.

Here is how you can craft the Ferricore Sword:

<Recipe id="justdirethings:ferricore_sword" />

