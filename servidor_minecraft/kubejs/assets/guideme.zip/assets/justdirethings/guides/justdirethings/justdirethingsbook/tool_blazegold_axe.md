---
navigation:
  title: "Blazegold Axe"
  icon: "justdirethings:blazegold_axe"
  position: 10
  parent: justdirethings:tools.md
item_ids:
  - justdirethings:blazegold_axe
---

# Blazegold Axe

Cuts faster than the [Ferricore Axe](./tool_ferricore_axe.md). It possesses 'Lava Repair', automatically repairing itself in lava.

Blazegold Axe Crafting

<Recipe id="justdirethings:blazegold_axe" />

