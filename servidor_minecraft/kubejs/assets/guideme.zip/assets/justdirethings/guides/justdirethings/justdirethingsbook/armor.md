---
navigation:
  title: "Armor"
  icon: "justdirethings:ferricore_chestplate"
  position: 4
---

# Armor

<SubPages />