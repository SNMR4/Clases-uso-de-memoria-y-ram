---
navigation:
  title: "Blazebloom Goo"
  icon: "justdirethings:gooblock_tier2"
  position: 2
  parent: justdirethings:goo.md
item_ids:
  - justdirethings:gooblock_tier2
---

# Blazebloom Goo

Blazebloom Goo captures the fiery essence of the Nether. It can transform Gold into Blazegold, a material infused with solar energies that enhances both crafting and magical applications.

Ideal for intermediate alchemists, Blazebloom Goo represents a step up in the ability to manipulate and refine resources.

## Crafting Blazebloom Goo



<Recipe id="justdirethings:gooblock_tier2" />

