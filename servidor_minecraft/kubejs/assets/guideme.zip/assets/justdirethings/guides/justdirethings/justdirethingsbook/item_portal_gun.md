---
navigation:
  title: "Portal Gun"
  icon: "justdirethings:portalgun[justdirethings:forge_energy=100000]"
  position: 10
  parent: justdirethings:items.md
item_ids:
  - justdirethings:portalgun
---

# Portal Gun

The Portal Gun is a revolutionary device that enables the creation of portals. Left click to fire a projectile creating a blue portal, and right click for an orange portal. Step through one to emerge from the other, applicable to both players and items.

## Portal Gun Crafting



<Recipe id="justdirethings:portalgun" />

