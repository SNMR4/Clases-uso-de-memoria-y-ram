---
navigation:
  title: "Celestigem Paxel"
  icon: "justdirethings:celestigem_paxel[justdirethings:forge_energy=10000]"
  position: 19
  parent: justdirethings:tools.md
---

# Celestigem Paxel

The Celestigem Paxel combines the capabilities of a pickaxe, axe, and shovel. Crafted with the respective tools, it inherits their upgrades, offering versatility and extended utility.

Craft it by combining a Celestigem Pickaxe, Axe, and Shovel in a smithing table. Any installed upgrades on the tools will carry over to the paxel.

