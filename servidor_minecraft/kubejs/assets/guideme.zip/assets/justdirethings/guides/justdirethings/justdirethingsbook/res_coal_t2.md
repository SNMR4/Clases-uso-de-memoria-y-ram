---
navigation:
  title: "Blaze Ember"
  icon: "justdirethings:coal_t2"
  position: 22
  parent: justdirethings:resources.md
---

# Blaze Ember

Blaze Ember is crafted by placing a block of [Primal Coal](./res_coal_t1.md) next to a [Blazebloom Goo](./goo_tier2.md). It burns hotter and more efficiently than its predecessor, generating even more RF/T.

