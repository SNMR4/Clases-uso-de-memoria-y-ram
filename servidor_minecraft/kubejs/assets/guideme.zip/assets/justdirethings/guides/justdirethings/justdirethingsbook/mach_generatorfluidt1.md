---
navigation:
  title: "Simple Fuel Generator"
  icon: "justdirethings:generatorfluidt1"
  position: 20
  parent: justdirethings:machines.md
item_ids:
  - justdirethings:generatorfluidt1
---

# Simple Fuel Generator

See the [Refined Fuel](./res_refined_fuel_t2.md) sections for fuel options. There are 3 tiers of fuel available.

## Simple Fuel Generator



<Recipe id="justdirethings:generatorfluidt1" />

