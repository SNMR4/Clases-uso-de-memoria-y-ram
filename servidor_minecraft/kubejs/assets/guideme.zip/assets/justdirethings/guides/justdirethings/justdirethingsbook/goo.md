---
navigation:
  title: "Goo"
  icon: "justdirethings:gooblock_tier1"
---

# Goo

<SubPages />