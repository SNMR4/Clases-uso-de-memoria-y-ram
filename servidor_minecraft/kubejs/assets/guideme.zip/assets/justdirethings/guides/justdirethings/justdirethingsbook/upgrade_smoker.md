---
navigation:
  title: "Smoker"
  icon: "justdirethings:upgrade_smoker"
  position: 1
  parent: justdirethings:upgrades.md
item_ids:
  - justdirethings:upgrade_smoker
---

# Smoker

Enhance your culinary capabilities with the Smoker upgrade. Any drops from mobs will be smoked automatically! Beef will be turned into Steak.

Uses some durability.

## Smoker Upgrade Crafting



<Recipe id="justdirethings:upgrade_smoker" />

