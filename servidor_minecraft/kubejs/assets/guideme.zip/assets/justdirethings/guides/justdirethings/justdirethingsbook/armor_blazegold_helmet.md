---
navigation:
  title: "Blazegold Helmet"
  icon: "justdirethings:blazegold_helmet"
  position: 5
  parent: justdirethings:armor.md
item_ids:
  - justdirethings:blazegold_helmet
---

# Blazegold Helmet

The Blazegold Helmet offers superior protection compared to its Ferricore predecessor, enhanced with the unique Lava Repair ability. Drop this item into a lava source block to fully repair it.

## Blazegold Helmet Crafting



<Recipe id="justdirethings:blazegold_helmet" />

