---
navigation:
  title: "Refined Eclipse Ember Fuel"
  icon: "justdirethings:refined_t4_fluid_bucket"
  position: 29
  parent: justdirethings:resources.md
---

# Refined Eclipse Ember Fuel

To produce Refined Eclipse Ember Fuel, begin with Unrefined Eclipse Ember Fuel. This initial stage is made by dropping [Eclipse Ember](./res_coal_t4.md) into [Refined Voidflame Fuel](./res_refined_fuel_t3.md). Place the resulting fluid next to a Shadowpulse Goo block for the final refinement. This top-tier fuel offers the highest FE/T and total FE output, ideal for powering advanced machinery and systems.

Refined Eclipse Ember Fuel is an efficient fuel, and can be used to generate energy in the [Fuel Generator](./mach_generatorfluidt1.md).

