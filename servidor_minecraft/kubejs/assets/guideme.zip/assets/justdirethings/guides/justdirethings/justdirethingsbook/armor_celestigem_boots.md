---
navigation:
  title: "Celestigem Boots"
  icon: "justdirethings:celestigem_boots[justdirethings:forge_energy=10000]"
  position: 12
  parent: justdirethings:armor.md
item_ids:
  - justdirethings:celestigem_boots
---

# Celestigem Boots

Celestigem Boots are powered by Forge Energy with a total capacity of 10,000 FE. For optimal performance, maintain charge via a [Pocket Generator](./item_pocket_generator.md).

## Celestigem Boots Crafting



<Recipe id="justdirethings:celestigem_boots" />

