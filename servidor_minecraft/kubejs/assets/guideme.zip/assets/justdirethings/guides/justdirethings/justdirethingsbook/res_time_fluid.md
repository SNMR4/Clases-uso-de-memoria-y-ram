---
navigation:
  title: "Time Fluid"
  icon: "justdirethings:time_fluid_bucket"
  position: 31
  parent: justdirethings:resources.md
---

# Time Fluid

Time Fluid is a multi-purpose fluid powering all time altering Items and Blocks. It doesn't seem to be entirely part of this timesteam, as it is nearly transparent.

It is created by dropping a [Time Crystal](./res_time_crystal.md) into a pool of [Polymorphic Fluid.](./res_polymorphic_fluid.md)

