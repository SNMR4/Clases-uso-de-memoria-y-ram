---
navigation:
  title: "Time Protection"
  icon: "justdirethings:upgrade_time_protection"
  position: 1
  parent: justdirethings:upgrades.md
item_ids:
  - justdirethings:upgrade_time_protection
---

# Time Protection

[Time Crystals](./res_time_crystal.md) are amazing! However, they can sometimes have unintended side effects from carrying them around. Furthermore, they may lead to time altering fields and abilities after further research.

Equipping this upgrade will protection you from any strange effects from playing around with time!

## Walk Speed Upgrade Crafting



<Recipe id="justdirethings:upgrade_time_protection" />

