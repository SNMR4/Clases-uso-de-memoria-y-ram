---
navigation:
  title: "Decoy"
  icon: "justdirethings:upgrade_decoy"
  position: 1
  parent: justdirethings:upgrades.md
item_ids:
  - justdirethings:upgrade_decoy
---

# Decoy

Distract your enemies with the Decoy upgrade. Deploy a decoy to divert enemy attention, giving you a strategic advantage in combat.

Activate this ability with a bound hotkey to spawn a decoy. Nearby enemies will be forced to attack it for a duration until it despawns.

## Decoy Crafting



<Recipe id="justdirethings:upgrade_decoy" />

