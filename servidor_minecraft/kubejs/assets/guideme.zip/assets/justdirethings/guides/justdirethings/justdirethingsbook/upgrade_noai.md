---
navigation:
  title: "Mental Obliteration"
  icon: "justdirethings:upgrade_noai"
  position: 1
  parent: justdirethings:upgrades.md
item_ids:
  - justdirethings:upgrade_noai
---

# Mental Obliteration

The Mental Obliteration upgrade disables the artificial intelligence of the targeted mob. The mob will forever be completely brainless, taking no further action, due to a complete time lock on it's brain.

This is an activated ability, and must be bound to a hotkey in the tool settings menu.

## No AI Crafting



<Recipe id="justdirethings:upgrade_noai" />

