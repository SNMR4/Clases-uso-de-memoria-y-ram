---
navigation:
  title: "Lingering"
  icon: "justdirethings:upgrade_lingering"
  position: 1
  parent: justdirethings:upgrades.md
item_ids:
  - justdirethings:upgrade_lingering
---

# Lingering

Amplify your area of effect with the Lingering upgrade. This upgrade causes your bow's potions to leave a lingering effect, prolonging their impact on the environment and enemies.

## Lingering Crafting



<Recipe id="justdirethings:upgrade_lingering" />

