---
navigation:
  title: "Ferricore Chestplate"
  icon: "justdirethings:ferricore_chestplate"
  position: 2
  parent: justdirethings:armor.md
item_ids:
  - justdirethings:ferricore_chestplate
---

# Ferricore Chestplate

Offering robust protection, the Ferricore Chestplate is crafted to endure more than standard iron armor. It’s also eligible for special upgrades, enhancing its defensive capabilities.

## Ferricore Chestplate Crafting



<Recipe id="justdirethings:ferricore_chestplate" />

