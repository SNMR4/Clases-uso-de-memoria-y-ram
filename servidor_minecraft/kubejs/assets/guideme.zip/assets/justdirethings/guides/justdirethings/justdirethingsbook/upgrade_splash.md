---
navigation:
  title: "Splash"
  icon: "justdirethings:upgrade_splash"
  position: 1
  parent: justdirethings:upgrades.md
item_ids:
  - justdirethings:upgrade_splash
---

# Splash

Enhance your ranged attacks with the Splash upgrade. This upgrade converts arrow impacts into splash effects, spreading the impact over a wider area.

## Splash Upgrade Crafting



<Recipe id="justdirethings:upgrade_splash" />

