---
navigation:
  title: "Ferricore Axe"
  icon: "justdirethings:ferricore_axe"
  position: 4
  parent: justdirethings:tools.md
item_ids:
  - justdirethings:ferricore_axe
---

# Ferricore Axe

The Ferricore Axe is not only efficient at chopping wood but also effective as a weapon. It surpasses the iron axe in both durability and cutting speed and can be further enhanced with upgrades.

Ferricore Axe Crafting

<Recipe id="justdirethings:ferricore_axe" />

