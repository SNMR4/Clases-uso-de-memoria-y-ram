---
navigation:
  title: "Items"
  icon: "justdirethings:voidshift_wand[justdirethings:forge_energy=10000]"
  position: 6
---

# Items

<SubPages />