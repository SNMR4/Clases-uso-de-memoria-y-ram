---
navigation:
  title: "Eclipse Alloy Ingot"
  icon: "justdirethings:eclipsealloy_ingot"
  position: 7
  parent: justdirethings:resources.md
item_ids:
  - justdirethings:eclipsealloy_ingot
---

# Eclipse Alloy Ingot

Eclipse Alloy Ingots, obtained by smelting Raw Eclipse Alloy, offer unmatched durability and strength. They are derived from mining [Raw Eclipse Alloy Blocks](./res_eclipsealloy_raw.md), providing the ultimate material for crafting the most powerful and durable items.

## Smelting Raw Eclipse Alloy



<Recipe id="justdirethings:eclipsealloy_ingot_smelted" />

