---
navigation:
  title: "Death Protection"
  icon: "justdirethings:upgrade_deathprotection"
  position: 1
  parent: justdirethings:upgrades.md
item_ids:
  - justdirethings:upgrade_deathprotection
---

# Death Protection

Secure yourself against fatal damage with the Death Protection upgrade. Rewind Time to a point before you died, when you had a bit more health!

Requires a very large amount of forge energy, and has a very long cooldown.

## Death Protection Crafting



<Recipe id="justdirethings:upgrade_deathprotection" />

