---
navigation:
  title: "Eclipse Alloy Pickaxe"
  icon: "justdirethings:eclipsealloy_pickaxe[justdirethings:forge_energy=500000]"
  position: 21
  parent: justdirethings:tools.md
item_ids:
  - justdirethings:eclipsealloy_pickaxe
---

# Eclipse Alloy Pickaxe

The Eclipse Alloy Pickaxe combines immense durability with powerful energy storage, making it perfect for harvesting even the toughest materials. 

It is capable of supporting high-level mining enhancements.

Eclipse Alloy Pickaxe Crafting

<Recipe id="justdirethings:eclipsealloy_pickaxe" />

