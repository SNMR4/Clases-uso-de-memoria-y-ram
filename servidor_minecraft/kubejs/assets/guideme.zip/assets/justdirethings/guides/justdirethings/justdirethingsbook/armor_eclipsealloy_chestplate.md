---
navigation:
  title: "Eclipse Alloy Chestplate"
  icon: "justdirethings:eclipsealloy_chestplate[justdirethings:forge_energy=500000]"
  position: 21
  parent: justdirethings:armor.md
item_ids:
  - justdirethings:eclipsealloy_chestplate
---

# Eclipse Alloy Chestplate

This top-tier chestplate utilizes 500,000 FE of Forge Energy, offering unprecedented protection. Recharge it regularly with a [Pocket Generator](./item_pocket_generator.md) to ensure maximum efficiency.

## Eclipse Alloy Chestplate Crafting



<Recipe id="justdirethings:eclipsealloy_chestplate" />

