---
navigation:
  title: "Ore Scanner"
  icon: "justdirethings:upgrade_orescanner"
  position: 1
  parent: justdirethings:upgrades.md
item_ids:
  - justdirethings:upgrade_orescanner
---

# Ore Scanner

The Ore Scanner upgrade is an activated ability, and can be installed on pickaxes starting at Ferricore. When you activate this ability, nearby ores will appear with particles that you can see through blocks, but there is no differentiator between which ores are which.

## Ore Scanner Upgrade Crafting



<Recipe id="justdirethings:upgrade_orescanner" />

