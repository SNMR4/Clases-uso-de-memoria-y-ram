---
navigation:
  title: "Simple Block Placer"
  icon: "justdirethings:blockplacert1"
  position: 5
  parent: justdirethings:machines.md
item_ids:
  - justdirethings:blockplacert1
---

# Simple Block Placer

The Simple Block Placer automates the placement of blocks. When powered, it places the block held within its inventory into the space in front of it.

Use the direction button to indicate which 'direction' to place your items in. Useful for things like torches..

## Simple Block Placer



<Recipe id="justdirethings:blockplacert1" />

