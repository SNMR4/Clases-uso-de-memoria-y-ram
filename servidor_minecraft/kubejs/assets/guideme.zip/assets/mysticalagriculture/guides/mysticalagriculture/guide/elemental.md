---
navigation:
  title: "Elemental"
  icon: "mysticalagriculture:inferium_staff"
  position: 3
---

# Elemental

<SubPages />