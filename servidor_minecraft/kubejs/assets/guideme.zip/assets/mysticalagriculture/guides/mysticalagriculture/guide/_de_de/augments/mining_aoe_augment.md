---
navigation:
  title: "Abbau-AOE-Augment"
  icon: "mysticalagriculture:mining_aoe_iv_augment"
  position: 307
  parent: mysticalagriculture:augments.md
---

# Abbau-AOE-Augment

Das Abbau-AOE-Augment ist ein Werkzeug-Augment, das den Bereich vergrößert, in dem das Werkzeug Blöcke abbaut, bis zu 9x9. Schleichen während des Abbaus eines Blocks negiert den AOE-Effekt. 

Dieser Effekt kann durch Halten der Shift-Taste negiert werden.

