---
navigation:
  title: "Scythes"
  icon: "mysticalagriculture:inferium_scythe"
  position: 54
  parent: mysticalagriculture:advances.md
item_ids:
  - mysticalagriculture:diamond_scythe
  - mysticalagriculture:inferium_scythe
---

# Scythes

Scythes are used for harvesting large areas of crops by right clicking. Any fully grown crops within the area of effect will be harvested without being uprooted. 

Scythes are also an effective weapon with an increased attack AOE. 

Higher tier Scythes have a greater area of effect.

## Crafting



<Recipe id="mysticalagriculture:diamond_scythe" />

<Recipe id="mysticalagriculture:gear/inferium_scythe" />

