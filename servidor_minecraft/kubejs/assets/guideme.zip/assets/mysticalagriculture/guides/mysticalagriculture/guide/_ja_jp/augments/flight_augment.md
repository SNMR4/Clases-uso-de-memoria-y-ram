---
navigation:
  title: "飛行のオーグメント"
  icon: "mysticalagriculture:flight_augment"
  position: 316
  parent: mysticalagriculture:augments.md
---

# 飛行のオーグメント

飛行のオーグメントは、着用者にクリエイティブ飛行を与えるチェストプレート用のオーグメントです。

