---
navigation:
  title: "Erwecktes Supremium"
  icon: "mysticalagriculture:awakened_supremium_essence"
  position: 154
  parent: mysticalagriculture:elemental.md
---

# Erwecktes Supremium

Erwecktes Supremium ist ein hochstufiges Handwerksmaterial, das zur Erstellung verbesserter Versionen vieler Supremium-Gegenstände verwendet wird. 

Erwecktes Supremium wird **normalerweise** durch die Infusion von [Erkenntnisstaub](./cognizant_dust.md) mit einem Supremiumblock unter Verwendung eines [Erweckungsaltars](./awakening_altar.md) erstellt.

