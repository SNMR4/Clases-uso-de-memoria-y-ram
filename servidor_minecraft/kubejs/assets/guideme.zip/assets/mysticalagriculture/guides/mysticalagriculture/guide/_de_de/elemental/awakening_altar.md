---
navigation:
  title: "Erweckungsaltar"
  icon: "mysticalagriculture:awakening_altar"
  position: 153
  parent: mysticalagriculture:elemental.md
item_ids:
  - mysticalagriculture:awakening_altar
  - mysticalagriculture:awakening_pedestal
  - mysticalagriculture:essence_vessel
---

# Erweckungsaltar

Der Erweckungsaltar ist eine Handwerksstruktur, die **normalerweise** verwendet wird, um [Erwecktes Supremium](./awakened_supremium.md) zu erstellen. Die Struktur besteht aus 1 Infusionsaltar, 4 Infusionssockeln und 4 [Essenzurneen](./essence_vessel.md). 

Sobald ein Rezept an Ort und Stelle ist, muss der Altar nur noch mit einem Redstonesignal aktiviert werden.

## Werkbank



<Recipe id="mysticalagriculture:awakening_altar" />

<Recipe id="mysticalagriculture:awakening_pedestal" />

## Werkbank

Das Platzieren des Erweckungsaltars in der Welt zeigt, wo die Sockel und Gefäße platziert werden müssen.

<Recipe id="mysticalagriculture:essence_vessel" />

