---
navigation:
  title: "水中呼吸のオーグメント"
  icon: "mysticalagriculture:water_breathing_augment"
  position: 303
  parent: mysticalagriculture:augments.md
---

# 水中呼吸のオーグメント

水中呼吸のオーグメントは、着用者に水中呼吸を付与するヘルメット用のオーグメントです。

