---
navigation:
  title: "Basteltisch"
  icon: "mysticalagriculture:tinkering_table"
  position: 252
  parent: mysticalagriculture:tinkering.md
item_ids:
  - mysticalagriculture:tinkering_table
---

# Basteltisch

Der Basteltisch wird verwendet, um [Augments](./augments.md) zu [Essenzwerkzeugen](./essence_tools.md) und [Essenzrüstungen](./essence_armor.md) hinzuzufügen.

## Werkbank



<Recipe id="mysticalagriculture:tinkering_table" />

