---
navigation:
  title: "Kein Fallschaden-Augment"
  icon: "mysticalagriculture:no_fall_damage_augment"
  position: 308
  parent: mysticalagriculture:augments.md
---

# Kein Fallschaden-Augment

Das Kein Fallschaden-Augment ist ein Stiefel-Augment, das allen Fallschaden negiert, während die Rüstung getragen wird.

