---
navigation:
  title: "Experience Capsule"
  icon: "mysticalagriculture:experience_capsule"
  position: 106
  parent: mysticalagriculture:souls.md
item_ids:
  - mysticalagriculture:experience_capsule
---

# Experience Capsule

Experience Capsules are used to collect experience for creating Experience Seeds. 

To collect experience, simply have some Experience Capsules in your inventory and pick up Experience Orbs.

## Crafting



<Recipe id="mysticalagriculture:experience_capsule" />

