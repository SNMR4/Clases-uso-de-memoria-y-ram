---
navigation:
  title: "マスター注入のクリスタル"
  icon: "mysticalagriculture:master_infusion_crystal"
  position: 51
  parent: mysticalagriculture:advances.md
item_ids:
  - mysticalagriculture:master_infusion_crystal
---

# マスター注入のクリスタル

マスター注入のクリスタルは、無限の耐久値を持っています。これが欲しいんでしょう、分かってますよ。

## クラフト



<Recipe id="mysticalagriculture:master_infusion_crystal" />

