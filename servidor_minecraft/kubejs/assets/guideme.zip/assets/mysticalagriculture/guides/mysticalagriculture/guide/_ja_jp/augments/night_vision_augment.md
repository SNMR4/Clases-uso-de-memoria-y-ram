---
navigation:
  title: "暗視のオーグメント"
  icon: "mysticalagriculture:night_vision_augment"
  position: 302
  parent: mysticalagriculture:augments.md
---

# 暗視のオーグメント

暗視のオーグメントは、着用者に暗視を付与するヘルメット用のオーグメントです。

