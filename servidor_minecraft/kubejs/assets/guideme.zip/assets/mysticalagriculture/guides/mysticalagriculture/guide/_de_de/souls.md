---
navigation:
  title: "Seelen"
  icon: "mysticalagriculture:soulium_dagger"
  position: 2
---

# Seelen

<SubPages />