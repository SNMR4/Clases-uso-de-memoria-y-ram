---
navigation:
  title: "Ressourcenpflanzen"
  icon: "mysticalagriculture:prosperity_seed_base"
  position: 5
  parent: mysticalagriculture:basics.md
item_ids:
  - mysticalagriculture:prosperity_seed_base
---

# Ressourcenpflanzen

Ressourcenpflanzen sind das Herzstück in Mystical Agriculture. Es gibt jedoch einige besondere Eigenschaften von Ressourcenpflanzen, die beachtet werden sollten. 


- Ressourcenpflanzen können nicht mit Knochenmehl angebaut werden. 
- Ressourcenpflanzen lassen keinen zweiten Samen fallen, es sei denn, sie werden auf [Essenz-Ackerland](./essence_farmland.md) gepflanzt.

## Werkbank

Ressourcenpflanzen werden **normalerweise** mit einem [Infusionsaltar](./infusion_altar.md) erstellt.

<Recipe id="mysticalagriculture:prosperity_seed_base" />

