---
navigation:
  title: "Sickles"
  icon: "mysticalagriculture:inferium_sickle"
  position: 53
  parent: mysticalagriculture:advances.md
item_ids:
  - mysticalagriculture:diamond_sickle
  - mysticalagriculture:inferium_sickle
---

# Sickles

Sickles are used for harvesting/destroying large areas of plant material. 

Higher tier Sickles will have a greater area of effect.

## Fabrication



<Recipe id="mysticalagriculture:diamond_sickle" />

<Recipe id="mysticalagriculture:gear/inferium_sickle" />

