---
navigation:
  title: "Water Breathing Augment"
  icon: "mysticalagriculture:water_breathing_augment"
  position: 303
  parent: mysticalagriculture:augments.md
---

# Water Breathing Augment

The Water Breathing Augment is a helmet augment that grants the wearer Water Breathing while they have the armor equipped.

