---
navigation:
  title: "Master Infusion Crystal"
  icon: "mysticalagriculture:master_infusion_crystal"
  position: 51
  parent: mysticalagriculture:advances.md
item_ids:
  - mysticalagriculture:master_infusion_crystal
---

# Master Infusion Crystal

The Master Infusion Crystal has infinite durability. You want this, I know you do.

## Fabrication



<Recipe id="mysticalagriculture:master_infusion_crystal" />

