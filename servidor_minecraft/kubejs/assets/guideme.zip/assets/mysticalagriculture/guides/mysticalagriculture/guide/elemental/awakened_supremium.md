---
navigation:
  title: "Awakened Supremium"
  icon: "mysticalagriculture:awakened_supremium_essence"
  position: 154
  parent: mysticalagriculture:elemental.md
---

# Awakened Supremium

Awakened Supremium is a high level crafting material used to create upgraded versions of many of your Supremium items. 

Awakened Supremium is **usually** created by infusing [Cognizant Dust](./cognizant_dust.md) with a Supremium Block using an [Awakening Altar](./awakening_altar.md).

