---
navigation:
  title: "Seelenspawner"
  icon: "mysticalagriculture:soulium_spawner"
  position: 205
  parent: mysticalagriculture:machines.md
item_ids:
  - mysticalagriculture:soulium_spawner
---

# Seelenspawner

Der Seelenspawner wird verwendet, um sowohl feindliche als auch friedliche Mobs mit Essenzen zu spawnen. Sie laufen mit festen Brennstoffen und haben einen internen Energiespeicher. 

Der Spawner hat ein internes Inventar, das bis zu 512 Gegenstände aufnehmen kann. Jede Operation benötigt eine bestimmte Menge an Gegenständen und Energie, um den entsprechenden Mob zu spawnen.

## Werkbank

Der Spawner spawnt den Mob zufällig in einem Radius von 3 Blöcken um ihn herum. 

Diese Maschinen können mit [Maschinen-Upgrades](./machine_upgrades.md) aufgerüstet werden. 

Der Seelenspawner kann mit einem Redstonesignal deaktiviert werden.

<Recipe id="mysticalagriculture:soulium_spawner" />

