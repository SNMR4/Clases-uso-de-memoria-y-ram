---
navigation:
  title: "Luck Augment"
  icon: "mysticalagriculture:luck_iii_augment"
  position: 322
  parent: mysticalagriculture:augments.md
---

# Luck Augment

The Luck Augment is an armor augment that improves loot drops from fishing or loot chests for the wearer while they have the armor equipped.

