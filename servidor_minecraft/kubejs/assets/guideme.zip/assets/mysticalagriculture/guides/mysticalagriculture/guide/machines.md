---
navigation:
  title: "Machines"
  icon: "mysticalagriculture:seed_reprocessor"
  position: 4
---

# Machines

<SubPages />