---
navigation:
  title: "Gießkanne"
  icon: "mysticalagriculture:watering_can"
  position: 8
  parent: mysticalagriculture:basics.md
item_ids:
  - mysticalagriculture:watering_can
---

# Gießkanne

Gießkannen werden verwendet, um das Pflanzenwachstum durch manuelle* Arbeit zu beschleunigen. Um eine Gießkanne zu füllen, einfach mit Rechtsklick auf einen Wasserquellblock klicken.

## Werkbank



<Recipe id="mysticalagriculture:watering_can" />

