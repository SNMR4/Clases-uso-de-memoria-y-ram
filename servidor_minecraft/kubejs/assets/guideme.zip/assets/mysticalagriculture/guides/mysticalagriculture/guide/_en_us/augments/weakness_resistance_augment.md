---
navigation:
  title: "Weakness Resistance Augment"
  icon: "mysticalagriculture:weakness_resistance_augment"
  position: 321
  parent: mysticalagriculture:augments.md
---

# Weakness Resistance Augment

The Weakness Resistance Augment is a chestplate augment that prevents the wearer from getting the Weakness effect while they have the armor equipped.

