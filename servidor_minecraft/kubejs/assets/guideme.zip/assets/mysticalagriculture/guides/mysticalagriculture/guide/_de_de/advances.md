---
navigation:
  title: "Fortschritte"
  icon: "mysticalagriculture:mystical_fertilizer"
  position: 1
---

# Fortschritte

<SubPages />