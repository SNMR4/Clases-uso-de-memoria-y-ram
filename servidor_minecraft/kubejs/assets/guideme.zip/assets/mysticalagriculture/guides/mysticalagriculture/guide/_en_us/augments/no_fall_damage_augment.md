---
navigation:
  title: "No Fall Damage Augment"
  icon: "mysticalagriculture:no_fall_damage_augment"
  position: 308
  parent: mysticalagriculture:augments.md
---

# No Fall Damage Augment

The No Fall Damage Augment is a boots augment that negates all fall damage for the wearer while they have the armor equipped.

