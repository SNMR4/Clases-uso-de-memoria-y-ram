---
navigation:
  title: "Prosperiumsplitter"
  icon: "mysticalagriculture:prosperity_shard"
  position: 1
  parent: mysticalagriculture:basics.md
---

# Prosperiumsplitter

Prosperiumsplitter sind das andere der beiden Basismaterialien in Mystical Agriculture. Sie werden verwendet, um magische Varianten von Grundmaterialien zu erstellen. Prosperiumsplitter können **normalerweise** durch das Abbauen aus dem Boden gewonnen werden.

