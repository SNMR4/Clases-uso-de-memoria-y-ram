---
navigation:
  title: "範囲道均しのオーグメント"
  icon: "mysticalagriculture:pathing_aoe_iv_augment"
  position: 304
  parent: mysticalagriculture:augments.md
---

# 範囲道均しのオーグメント

範囲道均しのオーグメントは、シャベルが土の道を作成する範囲を9x9まで増加させるシャベル用のオーグメントです。この効果はスニークしながらシャベルを使用したときのみ発動します。

