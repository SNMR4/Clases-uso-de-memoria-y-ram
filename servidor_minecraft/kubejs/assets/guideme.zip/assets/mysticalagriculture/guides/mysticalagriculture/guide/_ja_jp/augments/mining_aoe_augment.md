---
navigation:
  title: "範囲採掘のオーグメント"
  icon: "mysticalagriculture:mining_aoe_iv_augment"
  position: 307
  parent: mysticalagriculture:augments.md
---

# 範囲採掘のオーグメント

範囲採掘のオーグメントは、道具がブロックを破壊する範囲を最大9x9まで増加させる道具用のオーグメントです。

この効果はShiftキーを押している間は無効化されます。

