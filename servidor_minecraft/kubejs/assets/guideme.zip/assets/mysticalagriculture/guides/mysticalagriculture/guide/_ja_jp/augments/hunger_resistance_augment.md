---
navigation:
  title: "空腹耐性のオーグメント"
  icon: "mysticalagriculture:hunger_resistance_augment"
  position: 318
  parent: mysticalagriculture:augments.md
---

# 空腹耐性のオーグメント

空腹耐性のオーグメントは、着用者の空腹の効果を防ぐヘルメット用のオーグメントです。

