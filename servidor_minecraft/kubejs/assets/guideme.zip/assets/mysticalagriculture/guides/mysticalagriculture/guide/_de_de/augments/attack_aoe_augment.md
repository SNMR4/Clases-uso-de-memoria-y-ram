---
navigation:
  title: "Angriffs-AOE-Augment"
  icon: "mysticalagriculture:attack_aoe_iii_augment"
  position: 312
  parent: mysticalagriculture:augments.md
---

# Angriffs-AOE-Augment

Das Angriffs-AOE-Augment ist ein Schwert-Augment, das den Angriffsradius des Schwertes um bis zu 6 Blöcke erhöht.

