---
navigation:
  title: "Infusionsaltar"
  icon: "mysticalagriculture:infusion_altar"
  position: 9
  parent: mysticalagriculture:basics.md
item_ids:
  - mysticalagriculture:infusion_altar
  - mysticalagriculture:infusion_pedestal
---

# Infusionsaltar

Der Infusionsaltar ist eine Handwerksstruktur, die **normalerweise** verwendet wird, um Samen in Mystical Agriculture zu erstellen. Die Struktur besteht aus einem Infusionsaltar und 8 Infusionssockeln. 

Sobald ein Rezept an Ort und Stelle ist, muss der Altar nur noch mit einem Zauberstab oder einem Redstonesignal aktiviert werden.

## Werkbank



<Recipe id="mysticalagriculture:infusion_altar" />

<Recipe id="mysticalagriculture:infusion_pedestal" />

Das Platzieren des Infusionsaltars in der Welt zeigt, wo die Sockel platziert werden müssen. 

[Klicke hier für eine detaillierte Anleitung zur Verwendung des Infusionsaltars.](https://blakesmods.com/wiki/mysticalagriculture/guides/creating-seeds)

