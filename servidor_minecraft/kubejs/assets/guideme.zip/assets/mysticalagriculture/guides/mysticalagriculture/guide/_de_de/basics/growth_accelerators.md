---
navigation:
  title: "Wachstumsbeschleuniger"
  icon: "mysticalagriculture:inferium_growth_accelerator"
  position: 7
  parent: mysticalagriculture:basics.md
item_ids:
  - mysticalagriculture:inferium_growth_accelerator
---

# Wachstumsbeschleuniger

Wachstumsbeschleuniger werden verwendet, um die Wachstumsrate von Pflanzen zu erhöhen. Sie wenden zufällige Wachstumsticks auf die erste Pflanze an, die über ihnen innerhalb des angegebenen Bereichs platziert wird. 

Mehrere Wachstumsbeschleuniger jeder Stufe können gestapelt werden, solange die Pflanze innerhalb des Bereichs liegt.

## Werkbank

Der Bereich des Wachstumsbeschleunigers basiert darauf, dass er unter dem Ackerland platziert wird. 

[Klicke hier für eine detaillierte Anleitung zur Verwendung von Wachstumsbeschleunigern.](https://blakesmods.com/wiki/mysticalagriculture/guides/speeding-up-crop-growth)

<Recipe id="mysticalagriculture:inferium_growth_accelerator" />

