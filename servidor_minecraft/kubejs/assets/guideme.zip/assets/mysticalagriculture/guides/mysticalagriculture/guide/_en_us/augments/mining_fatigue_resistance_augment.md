---
navigation:
  title: "Mining Fatigue Resistance Augment"
  icon: "mysticalagriculture:mining_fatigue_resistance_augment"
  position: 314
  parent: mysticalagriculture:augments.md
---

# Mining Fatigue Resistance Augment

The Mining Fatigue Resistance Augment is an armor augment that prevents the wearer from getting the Mining Fatigue effect while they have the armor equipped.

