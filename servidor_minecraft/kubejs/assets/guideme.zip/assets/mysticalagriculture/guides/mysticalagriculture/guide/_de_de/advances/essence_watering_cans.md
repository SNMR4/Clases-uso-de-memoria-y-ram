---
navigation:
  title: "Essenz-Gießkannen"
  icon: "mysticalagriculture:inferium_watering_can"
  position: 52
  parent: mysticalagriculture:advances.md
item_ids:
  - mysticalagriculture:inferium_watering_can
---

# Essenz-Gießkannen

Das Aufrüsten der normalen [Gießkanne](../basics/watering_can.md) mit Essenzen und [Mystischem Dünger](./mystical_fertilizer.md) verbessert das Pflanzenwachstum erheblich. 

Aufgerüstete Gießkannen haben eine verbesserte Reichweite und Wachstumsbeschleunigung. Automatisches Gießen kann durch Shift + Rechtsklick mit der Gießkanne aktiviert werden, während kein Block anvisiert wird.

## Werkbank



<Recipe id="mysticalagriculture:gear/inferium_watering_can" />

