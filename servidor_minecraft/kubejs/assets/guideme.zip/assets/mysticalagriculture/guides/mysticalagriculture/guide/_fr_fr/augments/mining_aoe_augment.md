---
navigation:
  title: "Mining AOE Augment"
  icon: "mysticalagriculture:mining_aoe_iv_augment"
  position: 307
  parent: mysticalagriculture:augments.md
---

# Mining AOE Augment

The Mining AOE Augment is a tool augment that increases the are that the tool breaks blocks, up to 9x9. Sneaking while breaking a block will negate the AOE effect.

