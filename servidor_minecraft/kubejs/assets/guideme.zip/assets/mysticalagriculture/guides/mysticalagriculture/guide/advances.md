---
navigation:
  title: "Advances"
  icon: "mysticalagriculture:mystical_fertilizer"
  position: 1
---

# Advances

<SubPages />