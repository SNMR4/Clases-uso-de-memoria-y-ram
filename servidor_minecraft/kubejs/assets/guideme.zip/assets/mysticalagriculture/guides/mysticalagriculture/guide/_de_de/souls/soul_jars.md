---
navigation:
  title: "Seelengefäße"
  icon: "mysticalagriculture:soul_jar"
  position: 104
  parent: mysticalagriculture:souls.md
item_ids:
  - mysticalagriculture:soul_jar
---

# Seelengefäße

Seelengefäße werden in Kombination mit einem [Seelendolch](./soulium_dagger.md) verwendet, um Mob-Seelen zu sammeln. Gefüllte Seelengefäße können verwendet werden, um [Ressourcenpflanzen](../basics/resource_crops.md) für die entsprechende Entität zu erstellen. 

Seelengefäße können auch mit Mob-Drops mit einem [Seelenextraktor](../machines/soul_extractor.md) gefüllt werden.

## Werkbank



<Recipe id="mysticalagriculture:soul_jar" />

