---
navigation:
  title: "Elemental Essences"
  icon: "mysticalagriculture:air_essence"
  position: 150
  parent: mysticalagriculture:elemental.md
---

# Elemental Essences

Air, Earth, Water and Fire essences can be used in [Awakening Altar](./awakening_altar.md) recipes using [Essence Vessels](./essence_vessel.md). 

Elemental seeds can be planted on [Tier 1 Essence Farmland](../basics/essence_farmland.md) for additional drops.

