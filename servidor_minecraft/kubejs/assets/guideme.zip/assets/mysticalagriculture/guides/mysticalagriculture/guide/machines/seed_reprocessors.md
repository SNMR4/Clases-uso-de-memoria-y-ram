---
navigation:
  title: "Seed Reprocessor"
  icon: "mysticalagriculture:seed_reprocessor"
  position: 202
  parent: mysticalagriculture:machines.md
item_ids:
  - mysticalagriculture:seed_reprocessor
---

# Seed Reprocessor

Seed Reprocessors are used to convert your excess seeds into their respective essences. They run off of solid fuels and have an internal power storage buffer.

## Crafting



<Recipe id="mysticalagriculture:seed_reprocessor" />

