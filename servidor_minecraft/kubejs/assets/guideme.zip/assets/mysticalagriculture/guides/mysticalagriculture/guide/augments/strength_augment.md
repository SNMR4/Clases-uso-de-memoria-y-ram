---
navigation:
  title: "Strength Augment"
  icon: "mysticalagriculture:strength_iii_augment"
  position: 311
  parent: mysticalagriculture:augments.md
item_ids:
  - mysticalagriculture:strength_iii_augment
---

# Strength Augment

The Strength Augment is a sword augment that increases the amount of damage the sword deals by 5-20.

