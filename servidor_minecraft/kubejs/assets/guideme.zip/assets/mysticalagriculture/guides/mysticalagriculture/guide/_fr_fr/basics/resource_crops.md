---
navigation:
  title: "Resource Crops"
  icon: "mysticalagriculture:prosperity_seed_base"
  position: 5
  parent: mysticalagriculture:basics.md
item_ids:
  - mysticalagriculture:prosperity_seed_base
---

# Resource Crops

Resource Crops are the heart and soul of what makes Mystical Agriculture so great. However, there are some special properties of resource crops that should be noted. 


- Resource Crops can not be grown using Bonemeal. 
- Resource Crops do not drop a second seed unless planted on [Essence Farmland](./essence_farmland.md).

## Fabrication

Resource Crops are **usually** created using an [Infusion Altar](./infusion_altar.md).

<Recipe id="mysticalagriculture:prosperity_seed_base" />

