---
navigation:
  title: "Speed Augment"
  icon: "mysticalagriculture:speed_iii_augment"
  position: 306
  parent: mysticalagriculture:augments.md
---

# Speed Augment

The Speed Augment is a leggings augment that increases the wearers movement speed while they have the armor equipped. This effect is also applied to flight speed.

