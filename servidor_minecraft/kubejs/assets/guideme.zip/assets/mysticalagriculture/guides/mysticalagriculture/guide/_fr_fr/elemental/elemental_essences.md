---
navigation:
  title: "Elemental Essences"
  icon: "mysticalagriculture:air_essence"
  position: 150
  parent: mysticalagriculture:elemental.md
---

# Elemental Essences

WIP 

Air, Earth, Water and Fire essences can be used in [Awakening Altar](./awakening_altar.md) recipes using [Essence Vessels](./essence_vessel.md).

