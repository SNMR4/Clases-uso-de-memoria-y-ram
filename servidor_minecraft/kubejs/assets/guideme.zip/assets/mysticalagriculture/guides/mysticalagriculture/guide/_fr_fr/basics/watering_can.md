---
navigation:
  title: "Watering Can"
  icon: "mysticalagriculture:watering_can"
  position: 8
  parent: mysticalagriculture:basics.md
item_ids:
  - mysticalagriculture:watering_can
---

# Watering Can

Watering Cans are used to accelerate crop growth using manual* labor. To fill one up, simply right click on a Water source block.

## Fabrication



<Recipe id="mysticalagriculture:watering_can" />

