---
navigation:
  title: "Flug-Augment"
  icon: "mysticalagriculture:flight_augment"
  position: 316
  parent: mysticalagriculture:augments.md
---

# Flug-Augment

Das Flug-Augment ist ein Brustpanzer-Augment, das dem Träger kreatives Fliegen ermöglicht, solange er die Rüstung trägt.

