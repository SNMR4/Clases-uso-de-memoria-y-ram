---
navigation:
  title: "Fertilized Essence"
  icon: "mysticalagriculture:fertilized_essence"
  position: 10
  parent: mysticalagriculture:basics.md
---

# Fertilized Essence

Fertilized Essence **usually** drops from all [Resource Crops](./resource_crops.md) **except Inferium**. It works identically to Bonemeal, but also works on [Resource Crops](./resource_crops.md)! 

Fertilized Essence can also be used to more efficiently craft [Mystical Fertilizer](../advances/mystical_fertilizer.md).

