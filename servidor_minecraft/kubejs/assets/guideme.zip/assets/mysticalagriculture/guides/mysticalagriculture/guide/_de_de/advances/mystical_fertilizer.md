---
navigation:
  title: "Mystischer Dünger"
  icon: "mysticalagriculture:mystical_fertilizer"
  position: 50
  parent: mysticalagriculture:advances.md
item_ids:
  - mysticalagriculture:mystical_fertilizer
---

# Mystischer Dünger

Mystischer Dünger wird verwendet, um eine Pflanze oder einen Setzling sofort wachsen zu lassen. Er ist auch auf [Ressourcenpflanzen](../basics/resource_crops.md) wirksam!

## Werkbank



<Recipe id="mysticalagriculture:mystical_fertilizer" />

<Recipe id="mysticalagriculture:mystical_fertilizer_better" />

