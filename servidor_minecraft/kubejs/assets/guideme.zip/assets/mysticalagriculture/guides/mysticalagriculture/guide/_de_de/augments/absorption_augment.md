---
navigation:
  title: "Absorptions-Augment"
  icon: "mysticalagriculture:absorption_v_augment"
  position: 300
  parent: mysticalagriculture:augments.md
---

# Absorptions-Augment

Das Absorptions-Augment ist ein Rüstungs-Augment, das dem Benutzer alle 8 Minuten 2-10 Absorptionsherzen gewährt, während die Rüstung getragen wird.

