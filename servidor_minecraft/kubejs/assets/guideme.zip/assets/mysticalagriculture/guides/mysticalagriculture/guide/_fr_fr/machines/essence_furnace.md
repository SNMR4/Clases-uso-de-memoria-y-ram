---
navigation:
  title: undefined
  icon: "mysticalagriculture:furnace"
  position: 201
  parent: mysticalagriculture:machines.md
item_ids:
  - mysticalagriculture:furnace
---

# undefined



## Fabrication



<Recipe id="mysticalagriculture:furnace" />

