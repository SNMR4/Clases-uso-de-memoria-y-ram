---
navigation:
  title: "Übelkeitsresistenz-Augment"
  icon: "mysticalagriculture:nausea_resistance_augment"
  position: 319
  parent: mysticalagriculture:augments.md
---

# Übelkeitsresistenz-Augment

Das Übelkeitsresistenz-Augment ist ein Helm-Augment, das verhindert, dass der Träger den Übelkeitseffekt erhält, solange er die Rüstung trägt.

