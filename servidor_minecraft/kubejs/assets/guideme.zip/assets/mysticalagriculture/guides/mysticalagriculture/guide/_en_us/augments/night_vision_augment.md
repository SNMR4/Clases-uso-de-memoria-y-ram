---
navigation:
  title: "Night Vision Augment"
  icon: "mysticalagriculture:night_vision_augment"
  position: 302
  parent: mysticalagriculture:augments.md
---

# Night Vision Augment

The Night Vision Augment is a helmet augment that grants the wearer Night Vision while they have the armor equipped.

