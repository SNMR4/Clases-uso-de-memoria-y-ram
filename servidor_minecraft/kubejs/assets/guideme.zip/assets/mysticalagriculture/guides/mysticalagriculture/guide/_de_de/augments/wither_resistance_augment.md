---
navigation:
  title: "Verdorrungsresistenz-Augment"
  icon: "mysticalagriculture:wither_resistance_augment"
  position: 315
  parent: mysticalagriculture:augments.md
---

# Verdorrungsresistenz-Augment

Das Verdorrungsresistenz-Augment ist ein Rüstungs-Augment, das verhindert, dass der Träger den Verdorrungseffekt erhält, solange er die Rüstung trägt.

