---
navigation:
  title: "Inferiumessenz"
  icon: "mysticalagriculture:inferium_essence"
  parent: mysticalagriculture:basics.md
---

# Inferiumessenz

Inferiumessenz ist eine der beiden Basismaterialien in Mystical Agriculture. Es wird zur Herstellung von fast allem im Mod verwendet. Inferiumessenz kann **normalerweise** durch das Töten von feindlichen oder friedlichen Mobs, das Abbauen aus dem Boden oder das Anbauen gewonnen werden.

