---
navigation:
  title: "Blindness Resistance Augment"
  icon: "mysticalagriculture:blindness_resistance_augment"
  position: 317
  parent: mysticalagriculture:augments.md
---

# Blindness Resistance Augment

The Blindness Resistance Augment is a helmet augment that prevents the wearer from getting the Blindness effect while they have the armor equipped.

