---
navigation:
  title: "Elementare Essenzen"
  icon: "mysticalagriculture:air_essence"
  position: 150
  parent: mysticalagriculture:elemental.md
---

# Elementare Essenzen

Luft-, Erd-, Wasser- und Feueressenzen können in [Erweckungsaltar](./awakening_altar.md)-Rezepten unter Verwendung von [Essenzurnen](./essence_vessel.md) verwendet werden. 

Elementarsamen können auf [Stufe 1 Essenz-Ackerland](../basics/essence_farmland.md) für zusätzliche Erträge gepflanzt werden.

