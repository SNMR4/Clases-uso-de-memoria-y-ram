---
navigation:
  title: "Meister-Infusionskristall"
  icon: "mysticalagriculture:master_infusion_crystal"
  position: 51
  parent: mysticalagriculture:advances.md
item_ids:
  - mysticalagriculture:master_infusion_crystal
---

# Meister-Infusionskristall

Der Meister-Infusionskristall hat unendliche Haltbarkeit. Diesen Kristall will man haben, das ist sicher.

## Werkbank



<Recipe id="mysticalagriculture:master_infusion_crystal" />

