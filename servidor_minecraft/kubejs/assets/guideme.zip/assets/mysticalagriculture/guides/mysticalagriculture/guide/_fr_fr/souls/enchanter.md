---
navigation:
  title: undefined
  icon: "mysticalagriculture:enchanter"
  position: 110
  parent: mysticalagriculture:souls.md
item_ids:
  - mysticalagriculture:enchanter
---

# undefined



## Fabrication



<Recipe id="mysticalagriculture:enchanter" />

