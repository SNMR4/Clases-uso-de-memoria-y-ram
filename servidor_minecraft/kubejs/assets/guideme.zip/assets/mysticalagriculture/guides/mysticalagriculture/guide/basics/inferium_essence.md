---
navigation:
  title: "Inferium Essence"
  icon: "mysticalagriculture:inferium_essence"
  parent: mysticalagriculture:basics.md
---

# Inferium Essence

Inferium Essence is one of the two base materials in Mystical Agriculture. It's used in the creation of pretty much everything in the mod. You can **usually** obtain Inferium Essence by killing hostile or passive mobs, mining it from the ground, or growing it.

