---
navigation:
  title: "Giftresistenz-Augment"
  icon: "mysticalagriculture:poison_resistance_augment"
  position: 313
  parent: mysticalagriculture:augments.md
---

# Giftresistenz-Augment

Das Giftresistenz-Augment ist ein Rüstungs-Augment, das verhindert, dass der Träger vergiftet wird, solange er die Rüstung trägt.

