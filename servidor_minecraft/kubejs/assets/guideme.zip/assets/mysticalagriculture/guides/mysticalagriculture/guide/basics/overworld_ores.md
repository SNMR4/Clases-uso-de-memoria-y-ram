---
navigation:
  title: "Overworld Ores"
  icon: "mysticalagriculture:inferium_ore"
  position: 4
  parent: mysticalagriculture:basics.md
---

# Overworld Ores

<ItemImage id="mysticalagriculture:inferium_ore" />

Inferium Ore **usually** spawns between Y level -32 and 64 in the Overworld.

<ItemImage id="mysticalagriculture:prosperity_ore" />

Prosperity Ore **usually** spawns between Y level -60 and 24 in the Overworld.

