---
navigation:
  title: "Schrittunterstützungs-Augment"
  icon: "mysticalagriculture:step_assist_augment"
  position: 310
  parent: mysticalagriculture:augments.md
---

# Schrittunterstützungs-Augment

Das Schrittunterstützungs-Augment ist ein Hosen- oder Stiefel-Augment, das es dem Träger ermöglicht, 1 Block hohe Höhen ohne Springen zu überwinden, solange er die Rüstung trägt. 

Dieser Effekt kann durch Halten der Umschalttaste negiert werden.

