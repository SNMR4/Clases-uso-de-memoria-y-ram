---
navigation:
  title: "Witherproof Blocks"
  icon: "mysticalagriculture:witherproof_block"
  position: 102
  parent: mysticalagriculture:souls.md
item_ids:
  - mysticalagriculture:witherproof_block
  - mysticalagriculture:witherproof_glass
---

# Witherproof Blocks

Witherproof Blocks are unbreakable by the Wither. Very useful for those who like to cheese bosses. 

They are also immune to damage from the Ender Dragon, however it can still fly though them.

## Crafting



<Recipe id="mysticalagriculture:witherproof_block" />

<Recipe id="mysticalagriculture:witherproof_glass" />

