---
navigation:
  title: "Essence Farmland"
  icon: "mysticalagriculture:inferium_farmland"
  position: 6
  parent: mysticalagriculture:basics.md
item_ids:
  - mysticalagriculture:inferium_farmland
---

# Essence Farmland

Essence Farmland increases the output efficiency of Mystical Agriculture crops in multiple ways. They are listed on the following page. 

You can create Essence Farmland by either right-clicking on Farmland in-world with an essence or by crafting it.


- Crops will **usually** have a 10 percent chance to drop a second seed when planted on any tier Essence Farmland. $
- Crops will have an additional 10 percent chance to drop a second seed when planted on the corresponding tier Essence Farmland. 
- Inferium Seeds will drop more essences when planted on higher tier Essence Farmland.

## Fabrication



<Recipe id="mysticalagriculture:inferium_farmland" />

<Recipe id="mysticalagriculture:inferium_farmland_till" />

