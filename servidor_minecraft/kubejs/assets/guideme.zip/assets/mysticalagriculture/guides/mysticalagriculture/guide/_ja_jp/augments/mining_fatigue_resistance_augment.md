---
navigation:
  title: "採掘速度低下耐性のオーグメント"
  icon: "mysticalagriculture:mining_fatigue_resistance_augment"
  position: 314
  parent: mysticalagriculture:augments.md
---

# 採掘速度低下耐性のオーグメント

採掘速度低下耐性のオーグメントは、着用者の採掘速度低下の効果を防ぐ防具用のオーグメントです。

