---
navigation:
  title: "吐き気耐性のオーグメント"
  icon: "mysticalagriculture:nausea_resistance_augment"
  position: 319
  parent: mysticalagriculture:augments.md
---

# 吐き気耐性のオーグメント

吐き気耐性のオーグメントは、着用者の吐き気の効果を防ぐヘルメット用のオーグメントです。

