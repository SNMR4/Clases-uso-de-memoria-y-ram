---
navigation:
  title: "Slowness Resistance Augment"
  icon: "mysticalagriculture:slowness_resistance_augment"
  position: 320
  parent: mysticalagriculture:augments.md
---

# Slowness Resistance Augment

The Slowness Resistance Augment is a leggings augment that prevents the wearer from getting the Slowness effect while they have the armor equipped.

