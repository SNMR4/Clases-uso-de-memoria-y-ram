---
navigation:
  title: "Furnace"
  icon: "mysticalagriculture:furnace"
  position: 201
  parent: mysticalagriculture:machines.md
item_ids:
  - mysticalagriculture:furnace
---

# Furnace

The basic furnace can be upgraded to take advantage of [Machine Upgrades](./machine_upgrades.md) for increased cooking speed. They run off of solid fuels and have an internal power storage buffer.

## Crafting



<Recipe id="mysticalagriculture:furnace" />

