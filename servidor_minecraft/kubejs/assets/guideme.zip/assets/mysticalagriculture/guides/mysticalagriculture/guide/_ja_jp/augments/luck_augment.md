---
navigation:
  title: "幸運のオーグメント"
  icon: "mysticalagriculture:luck_iii_augment"
  position: 322
  parent: mysticalagriculture:augments.md
---

# 幸運のオーグメント

幸運のオーグメントは、着用者の釣りやルートチェストのドロップを改善する防具用のオーグメントです。

