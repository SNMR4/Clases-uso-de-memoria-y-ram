---
navigation:
  title: "火炎耐性のオーグメント"
  icon: "mysticalagriculture:fire_resistance_augment"
  position: 309
  parent: mysticalagriculture:augments.md
---

# 火炎耐性のオーグメント

火炎耐性のオーグメントは、着用者に火炎耐性を付与する防具用のオーグメントです。

