---
navigation:
  title: "Flight Augment"
  icon: "mysticalagriculture:flight_augment"
  position: 316
  parent: mysticalagriculture:augments.md
---

# Flight Augment

The Flight Augment is a chestplate augment that gives the wearer creative flight while they have the armor equipped.

