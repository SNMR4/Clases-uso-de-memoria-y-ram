---
navigation:
  title: "Basteln"
  icon: "mysticalagriculture:inferium_pickaxe"
  position: 5
---

# Basteln

<SubPages />