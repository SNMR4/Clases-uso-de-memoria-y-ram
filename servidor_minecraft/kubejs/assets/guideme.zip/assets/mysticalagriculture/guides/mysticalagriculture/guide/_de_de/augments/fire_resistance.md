---
navigation:
  title: "Feuerresistenz-Augment"
  icon: "mysticalagriculture:fire_resistance_augment"
  position: 309
  parent: mysticalagriculture:augments.md
---

# Feuerresistenz-Augment

Das Feuerresistenz-Augment ist ein Rüstungs-Augment, das dem Träger Feuerresistenz gewährt, solange er die Rüstung trägt.

