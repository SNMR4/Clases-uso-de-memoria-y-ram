---
navigation:
  title: "Attack AOE Augment"
  icon: "mysticalagriculture:attack_aoe_iii_augment"
  position: 312
  parent: mysticalagriculture:augments.md
---

# Attack AOE Augment

The Attack AOE Augment is a sword augment that increases the attack radius of the sword by up to 6 blocks.

