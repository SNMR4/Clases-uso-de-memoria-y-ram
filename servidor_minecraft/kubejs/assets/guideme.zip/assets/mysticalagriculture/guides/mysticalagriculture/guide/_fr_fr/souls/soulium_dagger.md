---
navigation:
  title: "Soulium Dagger"
  icon: "mysticalagriculture:soulium_dagger"
  position: 103
  parent: mysticalagriculture:souls.md
item_ids:
  - mysticalagriculture:soulium_dagger
---

# Soulium Dagger

The Soulium Dagger is used to collect souls from mobs. These souls are collected using [Soul Jars](./soul_jars.md). Souls are collected by killing mobs with the Soulium Dagger 

The Soulium Dagger can be upgraded using an [Infusion Altar](../basics/infusion_altar.md), improving soul collection efficiency.

## Fabrication



<Recipe id="mysticalagriculture:soulium_dagger" />

<ItemImage id="mysticalagriculture:passive_soulium_dagger" />

The Passive Attuned Soulium Dagger provides an additional +50 percent souls gathered from passive mobs.

<ItemImage id="mysticalagriculture:hostile_soulium_dagger" />

The Hostile Attuned Soulium Dagger provides an additional +50 percent souls gathered from hostile mobs.

