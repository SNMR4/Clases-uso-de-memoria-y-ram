---
navigation:
  title: "Unterwasseratmungs-Augment"
  icon: "mysticalagriculture:water_breathing_augment"
  position: 303
  parent: mysticalagriculture:augments.md
---

# Unterwasseratmungs-Augment

Das Unterwasseratmungs-Augment ist ein Helm-Augment, das dem Träger Unterwasseratmung gewährt, während die Rüstung getragen wird.

