---
navigation:
  title: "Erfahrungskapsel"
  icon: "mysticalagriculture:experience_capsule"
  position: 106
  parent: mysticalagriculture:souls.md
item_ids:
  - mysticalagriculture:experience_capsule
---

# Erfahrungskapsel

Erfahrungskapseln werden verwendet, um Erfahrung für die Erstellung von Erfahrungssamen zu sammeln. 

Um Erfahrung zu sammeln, einfach einige Erfahrungskapseln im Inventar haben und Erfahrungskugeln aufsammeln.

## Werkbank



<Recipe id="mysticalagriculture:experience_capsule" />

