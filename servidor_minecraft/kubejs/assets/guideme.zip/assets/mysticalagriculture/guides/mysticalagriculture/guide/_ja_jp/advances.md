---
navigation:
  title: "発展"
  icon: "mysticalagriculture:mystical_fertilizer"
  position: 1
---

# 発展

<SubPages />