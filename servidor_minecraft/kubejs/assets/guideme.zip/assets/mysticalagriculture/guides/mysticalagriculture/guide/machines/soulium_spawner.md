---
navigation:
  title: "Soulium Spawner"
  icon: "mysticalagriculture:soulium_spawner"
  position: 205
  parent: mysticalagriculture:machines.md
item_ids:
  - mysticalagriculture:soulium_spawner
---

# Soulium Spawner

The Soulium Spawner is used to spawn both hostile and passive mobs using Essences. They run off of solid fuels and have an internal power storage buffer. 

The Spawner has an internal inventory that can hold up to 512 items. Each operation will take a certain amount of items and power to spawn a corresponding mob.

## Crafting

The Spawner will spawn the mob randomly in a 3 block radius around it. 

These machines can upgraded with [Machine Upgrades](./machine_upgrades.md). 

The Soulium Spawner can be de-activated with a Redstone signal.

<Recipe id="mysticalagriculture:soulium_spawner" />

