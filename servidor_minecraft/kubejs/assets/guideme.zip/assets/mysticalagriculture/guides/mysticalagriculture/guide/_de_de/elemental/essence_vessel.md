---
navigation:
  title: "Essenzurne"
  icon: "mysticalagriculture:essence_vessel"
  position: 152
  parent: mysticalagriculture:elemental.md
item_ids:
  - mysticalagriculture:essence_vessel
---

# Essenzurne

Essenzurnen werden in der [Erweckungsaltar](./awakening_altar.md)-Struktur verwendet, um die für die Erstellung von Gegenständen erforderlichen elementaren Essenzen zu halten. Jedes Gefäß kann bis zu 40 Essenzen einer einzigen Art aufnehmen.

## Werkbank



<Recipe id="mysticalagriculture:essence_vessel" />

