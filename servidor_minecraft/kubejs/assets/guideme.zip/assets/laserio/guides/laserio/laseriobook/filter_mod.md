---
navigation:
  title: "Mod Filter"
  icon: "laserio:filter_mod"
  position: 3
  parent: laserio:filters.md
---

# Mod Filter

The mod filter will sort based on what mod an item/block comes from. For example, if you place a Laser Wrench in the filter, all LaserIO items and blocks will match that filter.

