---
navigation:
  title: "Card Holder"
  icon: "laserio:card_holder"
  position: 2
  parent: laserio:items.md
item_ids:
  - laserio:card_holder
---

# Card Holder

The card holder is the solution to all your inventory woes! At least, the ones caused by this mod....Simply craft a Card Holder and right click it to open up the UI. Cards placed in this UI can stack up to 64, provided their NBT data matches. (Reminder: You can craft cards by themselves to reset their NBT)

Cards can be modified from within the holder - by right clicking on a cardstack (Just like in a laser node).

NOTE: If the stacksize of the card is larger than 1, it will disable the Filter and Overclocker slots to prevent item duping. #BlameSoaryn

By holding shift and right clicking the Card holder, it will start automatically pulling cards out of your inventory! You can tell this is activated because the card holder starts to glow as if it were enchanted. Shift-right click again to toggle it off. If you have the card holder in your inventory when you open a node, you'll see its cards displayed

NOTE: Filters and Overclockers can now be stored in the card holder!  Filters will only be automatically added to the card holder if they have no stored data. Craft them by themselves to clear any saved data.

Filters with stored data can still be manually added to the card holder.

## Card Holder



<Recipe id="laserio:card_holder" />

