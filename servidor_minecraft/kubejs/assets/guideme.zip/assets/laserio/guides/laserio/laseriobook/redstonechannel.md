---
navigation:
  title: "Redstone Channel"
  icon: "laserio:textures/gui/buttons/redstoneignore.png"
  position: 11
  parent: laserio:mechanics.md
---

# Redstone Channel

Cards have a 'redstone channel' separate from the main channel.

This is the channel of Redstone Signal that will affect the card. See more details in the [Redstone Mode](./redstonemode.md) and [Redstone Card](./card_redstone.md) sections.

