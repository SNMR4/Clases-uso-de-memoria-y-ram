---
navigation:
  title: "Regulate"
  icon: "laserio:textures/gui/buttons/regulatetrue.png"
  position: 9
  parent: laserio:mechanics.md
---

# Regulate

Regulate is only available on Stocker Mode.

Regulate ensures the counting filter will keep the specified amount of resources in the inventory, no more no less.

When Regulate mode is disabled, excess items will not be removed. If a stocker is requesting 32 cobblestone with a Counting Filter, and a player or another card adds more cobblestone, the excess cobblestone will not be removed.

With Regulate mode enabled, the excess cobble would be removed, if there is an inserter that can accept it.

